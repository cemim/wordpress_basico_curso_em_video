<?php

namespace MatthiasMullieSebcus\Minify;

/**
 * @deprecated Use Exceptions\BasicException instead
 *
 * @author Matthias Mullie <minify@mullie.eu>
 */
abstract class Exception extends \Exception
{
}
