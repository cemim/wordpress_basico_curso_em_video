<?php

namespace MatthiasMullieSebcus\Minify\Exceptions;

use MatthiasMullieSebcus\Minify\Exception;

/**
 * @author Matthias Mullie <minify@mullie.eu>
 */
abstract class BasicException extends Exception
{
}
